### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sapphireisone/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Sapphireisone/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f941d14f358d61a78fcb/maintainability)](https://codeclimate.com/github/Sapphireisone/python-project-lvl1/maintainability)


Asciinemas for games:
1. Brain-even:
    https://asciinema.org/a/1690tLC5kGIcpktm0YpKdIg1Q
2. Brain-calc:
    https://asciinema.org/a/FDWQZBMUd6OEQfjU6J95Tc7q5
3. Brain-gcd:
    https://asciinema.org/a/uVF6x0Pi2G75baGLhrGApmb7q
4. Brain-prime:
    https://asciinema.org/a/xsMTuTX97G2H6G1Ew6CNsFrgl
5. Brain-progression:
    https://asciinema.org/a/jwpkF0KNDGabjknsb2W5umKoh
