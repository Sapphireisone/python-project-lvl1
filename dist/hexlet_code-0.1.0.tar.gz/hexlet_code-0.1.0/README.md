### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sapphireisone/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Sapphireisone/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f941d14f358d61a78fcb/maintainability)](https://codeclimate.com/github/Sapphireisone/python-project-lvl1/maintainability)